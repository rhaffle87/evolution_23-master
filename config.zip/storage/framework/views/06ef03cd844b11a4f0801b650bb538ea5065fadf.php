

<?php $__env->startSection('title', 'Pembayaran Electra | Evolution 2022'); ?>

<?php $__env->startSection('container'); ?>

<div class="header bg-default pb-6">
        <div class="container-fluid">
            <div class="header-body">
                <div class="row align-items-center py-4">
                    <div class="col-lg-6 col-7">
                        <nav aria-label="breadcrumb" class="d-none d-md-inline-block ">
                            <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                                <li class="breadcrumb-item"><a><i class="fas fa-home" style="color: #172B4D"></i></a></li>
                                <li class="breadcrumb-item"><a style="color: #172B4D">Pembayaran</a></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Page content -->
    <div class="container-fluid mt--6">
        <div class="row">
            <div class="col-12" style="width: 100%;">
                <div class="card" style="width: 100%;">
                    <div class="card-body">
                        <h5 class="card-title" style="font-size: xx-large; text-align: center;">
                            <img src="/img/brand/TEXT_ELECTRA.png" alt="">
                            <!-- LOGO ELECTRA -->
                        </h5>

                        <div class="row">
                            <div class="col">


                                <?php if(($electra['pembayaran_status']==0) && $electra['email'] != null): ?>
                                <div class="alert alert-default" role="alert">
                                    <!-- 70.000 + 100 + 2 least unique ID -->
                                    Silahkan lakukan pembayaran sebesar <strong>Rp 50.<?php echo e(100+$electra['id']%100); ?></strong> ke salah satu rekening tercantum
                                    <br><br>
                                    <strong>BRI</strong>
                                    <br>
                                    761401001396503
                                    <br>
                                    a.n Wiradhika Elvian Aditya
                                    <br><br>
                                    <strong>OVO</strong>
                                    <br>
                                    08983457419
                                    <br>
                                    a.n Wiradhika Elvian
                                </div>
                                <?php endif; ?>

                                <?php if(($electra['pembayaran_status']==1) && $electra['email'] != null): ?>
                                <div class="alert alert-warning alert-block">
                                    Pembayaran sedang kami proses, maksimal dalam 2x24 jam
                                </div>
                                <?php endif; ?>

                                <?php if(($electra['pembayaran_status']==2 || $electra['pembayaran_status']==4) && $electra['email'] != null): ?>
                                <div class="alert alert-success alert-block">
                                    Pembayaran Anda telah berhasil kami terima, silahkan cetak kartu peserta.
                                </div>
                                <?php endif; ?>

                                <?php if(($electra['pembayaran_status']==3) && $electra['email'] != null): ?>
                                <div class="alert alert-warning alert-block">
                                    Verifikasi sedang kami proses
                                </div>
                                <?php endif; ?>

                                <?php if($electra['email'] == null): ?>
                                <div class="alert alert-warning alert-block">
                                    <strong>Anda belum mendaftar lomba apapun</strong>
                                </div>
                                <?php endif; ?>

                                <?php if($electra['email'] != null): ?>
                                <div class="card">
                                    <div class="card-body">

                                        <h6 class="heading text-muted mb-4">Konfirmasi Pembayaran</h6>
                                        <form action="<?php echo e(route('user.bayarElectra')); ?>" enctype="multipart/form-data" method="POST" id="pilihan-pembayaran">
                                            <?php echo csrf_field(); ?>


                                            <div class="form-group">
                                                <label class="form-control-label" for="input-school">Bank Tujuan</label>
                                                <select name="bank_tujuan" class="custom-select custom-select-lg mb-3" <?php echo e($electra['pembayaran_status']==0 ? '' : 'disabled'); ?> required>
                                                    <option hidden disabled selected>-- Pilih Bank --</option>
                                                    <option value="Bank BRI">Bank BRI</option>
                                                    <option value="OVO">OVO</option>
                                                </select>
                                            </div>

                                            <div class="form-group">
                                                <label class="form-control-label" for="input-school">Nama Pengirim</label>
                                                <input name="nama_pengirim" type="text" id="bank-account-number" class="form-control" placeholder="Nama Pengirim" value="<?php echo e($electra->pembayaran_atas_nama); ?>" <?php echo e($electra['pembayaran_status']==0 ? '' : 'readOnly'); ?> required>
                                            </div>

                                            <div class="form-group">
                                                <label for="exampleFormControlFile1">Unggah Bukti Pembayaran (Format jpg, jpeg)</label>
                                                <input name="file_bukti" accept="image/jpeg" type="file" class="form-control-file" id="bukti-pendaftaran" <?php echo e($electra['pembayaran_status']==0 ? '' : 'disabled'); ?> required>
                                            </div>

                                            <button type="submit" value="pembayaran" class="btn text-lighter" style="width: 100%; background-color: #264579;" <?php echo e($electra['pembayaran_status']==0 ? '' : 'disabled'); ?>>Submit</button>
                                            <hr class="my-4" />
                                        </form>

                                    </div>
                                </div>

                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user/template/user-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evolution_23\resources\views/user/bayar-electra.blade.php ENDPATH**/ ?>