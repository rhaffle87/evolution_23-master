<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Barryvdh\DomPDF\PDF;
use Illuminate\Contracts\Validation\Validator;

use App\Models\User;
use App\Models\Electra;


class UserController extends Controller
{
    public function register(Request $request)
    {
        echo "Register";
        $this->validate($request, [
            'name' => 'required|min:3',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
            'confirm-password' => 'required|same:password'
        ]);

        $user = new User;
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->level = 0;
        $user->register = 0;
        $simpan = $user->save();

        if ($simpan) {
            return redirect('/login')->with('success', 'Register Berhasil');
        } else {
            return redirect('/register')->with('error', 'Register Gagal');
        }
    }

    public function login(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required|min:6'
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();



            // check if level == 1
            if (Auth::user()->level == 1) {
                return redirect()->intended('/admin/dashboard');
            }
            return redirect()->intended('/user/dashboard');
        }

        return back()->withErrors([
            'email' => 'The provided credentials do not match our records.',
        ]);
    }

    public function RegisterElectra(Request $request)
    {
        // if logged in
        if (Auth::check()) {
            $electra = User::where('id', Auth::user()->id)->first();
            return view('User.daftar_electra', compact('electra'));
        } else {
            // return redirect('/login');
            echo "Awok";
        }
    }

    public function RegisterElectraSave(Request $request)
    {
        echo "wkwkwk";
        // $this->validate($request, [
        //     'nama' => 'required|min:3',
        //     'nim' => 'required|min:10',
        //     'no_hp' => 'required|min:10',
        //     'email' => 'required|email',
        //     'line' => 'required|min:3',
        //     'instagram' => 'required|min:3',
        //     'foto' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
        //     'cv' => 'required|mimes:pdf|max:2048',
        //     'ktm' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:204
        // ]);
    }

    public function updatePassword(Request $request)
    {
        if (Auth::user()) {

            // ambil data berdasarkan id
            $user = User::find(Auth::user()->id);

            // simpan form ke dalam variabel baru
            $passLama = $request->passwordLama;
            $passBaru = $request->passwordBaru;
            $passBaruKonfirmasi = $request->konfirmasiPasswordBaru;

            // cek apakah password lama sama atau tidak
            if (Hash::check($passLama, $user->password)) {

                // cek apakah password baru sama atau tidak
                if ($passBaru != $passBaruKonfirmasi) {
                    return redirect('/user/ganti-password')->with('failed-baru', 'Password baru tidak sama');
                } else {
                    // ganti password
                    $request->user()->fill([
                        'password' => Hash::make($request->passwordBaru)
                    ])->save();

                    return redirect('/user/ganti-password')->with('success', 'Password berhasil diganti');
                }
            } else {

                return redirect('/user/ganti-password')->with('failed-lama', 'Password lama tidak sesuai');
            }
        }
    }

    public function tampilanResetPassword()
    {
        return view('account.reset-password');
    }

    public function tampilanBayarElectra()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('user.bayar-electra', compact('electra'));
    }

    public function bayarElectra(Request $request)
    {
        $uploaded_filename = $request->file_bukti->store('public');
        $uploaded_filename = str_replace("public/", "", $uploaded_filename);

        $electra = Electra::where("email", "=", Auth::user()->email)->first();
        $electra->pembayaran_bank       = $request->bank_tujuan;
        $electra->pembayaran_atas_nama  = $request->nama_pengirim;
        $electra->pembayaran_status     = 1; //Sudah disubmit peserta, belum dikonfirmasi oleh admin
        $electra->pembayaran_bukti      = $uploaded_filename;
        $electra->save();

        return redirect('/user/pembayaran/electra');
    }

    public function tampilanKartuElectra()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('user.kartu-electra', compact('electra'));
    }

    public function unduhKartuElectra()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();
        $region = $electra->region;

        $e = 1;
        if ($region == null) {
            $x = 0;
            $y = 0;
            $e = 2;
        } else if ($region == 'Jabodetabek') {
            $x = 1;
            $y = 5;
        } else if ($region == 'Banyuwangi') {
            $x = 1;
            $y = 1;
        } else if ($region == 'Madiun') {
            $x = 0;
            $y = 9;
        } else if ($region == 'Tuban') {
            $x = 0;
            $y = 6;
        } else if ($region == 'Semarang') {
            $x = 1;
            $y = 4;
        } else if ($region == 'Malang') {
            $x = 0;
            $y = 5;
        } else if ($region == 'Surabaya') {
            $x = 0;
            $y = 1;
        } else if ($region == 'Sidoarjo') {
            $x = 0;
            $y = 2;
        } else if ($region == 'Bali') {
            $x = 1;
            $y = 6;
        } else if ($region == 'Gresik') {
            $x = 0;
            $y = 3;
        } else if ($region == 'Balikpapan') {
            $x = 1;
            $y = 7;
        } else if ($region == 'Jember') {
            $x = 1;
            $y = 0;
        } else if ($region == 'Kediri') {
            $x = 0;
            $y = 8;
        } else if ($region == 'Mojokerto') {
            $x = 0;
            $y = 4;
        } else if ($region == 'Madura') {
            $x = 1;
            $y = 2;
        } else if ($region == 'Probolinggo') {
            $x = 0;
            $y = 7;
        } else if ($region == 'Solo') {
            $x = 1;
            $y = 3;
        }

        $nomor_peserta = $electra->id;
        $syarat = $nomor_peserta / 10;
        if ($syarat < 1) {
            // 1 sampai 9
            $a = 0;
            $b = 0;
            $c = 0;
            $d = substr($nomor_peserta, 0, 1);
        } else if ($syarat < 10 && $syarat >= 1) {
            // 10 sampai 99
            $a = 0;
            $b = 0;
            $c = substr($nomor_peserta, 0, 1);
            $d = substr($nomor_peserta, 1, 1);
        } else if ($syarat >= 10 && $syarat < 100) {
            // 100 sampai 999
            $a = 0;
            $b = substr($nomor_peserta, 0, 1);
            $c = substr($nomor_peserta, 1, 1);
            $d = substr($nomor_peserta, 2, 1);
        } else if ($syarat >= 100) {
            // 1000 sampai 9999
            $a = substr($nomor_peserta, 0, 1);
            $b = substr($nomor_peserta, 1, 1);
            $c = substr($nomor_peserta, 2, 1);
            $d = substr($nomor_peserta, 3, 1);
        }

        $nomor_peserta_final = $x . $y . '-' . '20' . $a . '-' . $b . $c . $d . '-' . $e;

        $data = array(
            'nama_ketua' => $electra->nama_ketua,
            'nama_anggota' => $electra->nama_anggota,
            'nama_tim' => $electra->nama_tim,
            'sekolah' => $electra->sekolah,
            'nomor_peserta' => $nomor_peserta_final,
        );

        $pdf = PDF::loadView('document.kartu-peserta-electra', $data)->setPaper('a5', 'potrait');
        return $pdf->download('kartu-peserta.pdf');
    }

    public function tampilanFormElectra()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('user.daftar-electra', compact('electra'));
    }

    public function daftarElectra(Request $request)
    {
        $electraDaftar = Electra::where([['email', Auth::user()->email]])->first();

        // User register rules
        $rules = array('nama_tim' => 'unique:electras,nama_tim',);
        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails())
            return redirect('/user/daftar/electra')->with('failed', 'Nama Tim ini sudah digunakan');
        else {
            // convert to uppercase
            $request->nama_tim = strtoupper($request->nama_tim);
            $request->nama_ketua = strtoupper($request->nama_ketua);
            $request->nama_anggota = strtoupper($request->nama_anggota);

            if (!$electraDaftar) {
                $daftar = new Electra;
                $daftar->email              = Auth::user()->email;
                $daftar->nama_tim           = $request->nama_tim;
                $daftar->nama_ketua         = $request->nama_ketua;
                $daftar->kelas_ketua        = $request->kelas_ketua;
                $daftar->nama_anggota       = $request->nama_anggota;
                $daftar->kelas_anggota      = $request->kelas_anggota;
                $daftar->sekolah            = $request->sekolah;
                $daftar->alamat_sekolah     = $request->alamat_sekolah;
                $daftar->nomor_hp_ketua     = $request->nomor_hp_ketua;
                $daftar->nomor_hp_anggota   = $request->nomor_hp_anggota;
                $daftar->pembayaran_status  = 0;
                $daftar->file_ktp_ketua     = $request->file_ktp_ketua->store('public');
                $daftar->file_ktp_anggota   = $request->file_ktp_anggota->store('public');
                $daftar->save();
            }
            return redirect('/user/daftar/electra');
        }
    }
}
