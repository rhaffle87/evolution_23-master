<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Email</title>
</head>

<body>
    <p>
        Yaayy! Selamat pembayaran kamu telah dikonfirmasi.
        Terima kasih {{$nama}} atas partisipasinya dalam EVOLVE 2022. <br>
        Jangan lupa untuk bergabung pada grup <b>WhatsApp</b> peserta EVOLVE di link sebagai berikut : <br>

        link : https://intip.in/WA1Evolve2022 <br>

        <br> Jika ada yang ingin ditanyakan dapat menghubungi CP yang tertera pada dashboard EVOLUTION (EVOLVE)
    </p>
</body>

</html>