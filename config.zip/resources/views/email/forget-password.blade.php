<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Email</title>
</head>

<body>
    <p>
        Silahkan ganti password evolution anda dengan menekan link berikut. <br>
        <a href="{{ url('/pulihkan/') }}/{{$id}}" role="button">Reset Password</a>
    </p>
</body>

</html>