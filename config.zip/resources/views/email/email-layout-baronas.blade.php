<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Email</title>
</head>

<body>
    <p>
        Yaayy! Selamat pembayaran kamu telah dikonfirmasi.
        Terima kasih Tim {{$nama_tim}} atas partisipasinya dalam kompetisi BARONAS 2022. <br>
        Jangan lupa untuk bergabung pada grup <b>WhatsApp</b> peserta BARONAS di link sebagai berikut : <br>

        1. Kategori SD : https://intip.in/WAGrupKategoriSD <br>
        2. SMP : https://intip.in/WAGrupKategoriSMP <br>
        3. SMA : https://intip.in/WAGrupKategoriSMA <br>
        4. Umum : https://intip.in/WhatsAppGrupKategoriUmum <br>

        dan mengunduh kartu peserta kalian di web EVOLUTION 2022 yaitu evolution-its.com ya! <br>
        Tetap semangat untuk lomba nya yaa! Semoga mendapatkan hasil terbaik yang kalian impikan.<br>
        <br> Jika ada yang ingin ditanyakan dapat menghubungi CP : 081234858488 (Info BARONAS 2022)
    </p>
</body>

</html>
