

<?php $__env->startSection('title', 'Selamat Datang | Evolution 2022'); ?>

<?php $__env->startSection('container'); ?>

<!-- Header -->
<div class="header pb-6 d-flex align-items-center" style="min-height: 500px; background-image: url(/assets/img/bg-img/home-header.png); background-size: cover; background-position: center top; background-color: black;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-lg-12 col-md-10">
                <h1 class="display-2 text-white mb-5" style="font-size: 50px">SELAMAT DATANG <br> PESERTA EVOLUTION 2022</h1>

            </div>
        </div>
    </div>
</div>

<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row">
        <div class="col">
            <div class="card">


                <!-- Card header -->
                <div class="card-header border-0">

                    <h1 class="mb-0">PENGUMUMAN</h1>
                </div>
                <ul class="nav nav-tabs mx-4" id="myTab" role="tablist">

                    <!-- <li class="nav-item">
                        <a class="nav-link " id="electra-tab" data-toggle="tab" href="#electra" role="tab" aria-controls="home" aria-selected="false"><b>Electra</b></a>
                    </li> -->

                    <li class="nav-item">
                        <a class="nav-link active" id="baronas-tab" data-toggle="tab" href="#baronas" role="tab" aria-controls="profile" aria-selected="true"><b>Evolve</b></a>
                    </li>

                    <!-- <li class="nav-item">
                        <a class="nav-link" id="evolve-tab" data-toggle="tab" href="#evolve" role="tab"
                            aria-controls="contact" aria-selected="false"><b>Evolve</b></a>
                    </li> -->
                </ul>
                <div class="tab-content" id="myTabContent">


		<div class="tab-pane fade show active" id="evolve" role="tabpanel" aria-labelledby="baronas-tab">
                        <!-- Light table -->
                        <div class="table-responsive">
                            <table class="table align-items-center ">
                                <div class="media-body p-4">
                                    <div class="timeline mb-5">
                                        <h3>Time Line</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            Pendaftaran: 10 April 2022 s/d 27 Mei 2022 <br>
                                            Acara: Sabtu, 28 Mei 2022 <br>
                                        </span>
                                    </div>
                                    <div class="timeline mb-5">
                                        <h3>Biaya Pendaftaran</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            HTM : Rp. 15.000<br>
                                        </span>
                                    </div>
                                    <div class="info-pendaftaran mb-5">
                                        <h3>Informasi Pendaftaran</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">Pendaftaran Online
                                            <br>
                                            1. Peserta terlebih dahulu membuat akun yang berisi Email dan Password lalu
                                            klik Register.<br>
                                            2. Peserta kemudian melakukan proses verifikasi dengan mengikuti intruksi
                                            dari pesan masuk via email pribadi masing-masing.<br>
                                            3. Setelah diverifikasi, Peserta kembali ke web EVOLUTION dan akan muncul
                                            “Akun anda berhasil diverifikasi, silahkan login”. Login kembali dengan
                                            Email dan Password anda yang sudah didaftarkan sebelumnya.<br>
                                            4. Anda sudah berada di halaman awal EVOLUTION 2022. Tekan ikon 3 garis di
                                            sebelah pojok kiri atas lalu tekan pendaftaran dan pilih EVOLVE.<br>
                                            5. Peserta dipersilahkan mengisi data diri secara benar dan sesuai.<br>
                                            6. Setelah data pendaftaran telah tersimpan, langkah selanjutnya adalah
                                            pembayaran.<br>
                                            7. Peserta menekan ikon 3 garis di sebelah pojok kiri atas seperti
                                            sebelumnya, lalu pilih menu pembayaran dan klik EVOLVE.<br>
                                            8. Setelah melakukan konfirmasi pembayaran, Peserta menunggu verifikasi
                                            pembayaran maksimal 2x24 jam.<br>
                                            9. Setelah terverifikasi, Peserta akan mendapat Email Bukti pembayaran di
                                            akun email peserta masing-masing.<br>
                                            10. Pada laman pembayaran, akan muncul “Pembayaran Anda telah berhasil kami
                                            terima”<br>
                                            11. Silahkan bergabung dengan Grup WA dengan mengklik tautan yang sudah
                                            disediakan di Email konfirmasi pembayaran.<br>
                                            12. Selamat, anda telah teregistrasi pada acara EVOLVE 2022.<br>
                                            <br>Notes: Untuk kendala yang berhubungan dengan registrasi peserta bisa
                                            menghubungi Narahubung/Contact Person yang sudah disediakan <br>

                                    </div>
                                    </span>
                                    <div class="link-penting mb-5">
                                        <h3>Link Penting</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            1. Virtual Background : <a href="https://intip.in/vbevolve"
                                                target="blank">https://intip.in/vbevolve</a> <br>
                                    </div>
                                    <div class="contact-person mb-5">
                                        <h3>Contact Person</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            <b>Karina Adi P. </b><br>
                                            &emsp; id Line : k_adiputr<br>
                                            <b>Fatahillah R. </b><br>
                                            &emsp; id Line : kishino_hir<br>
                                            &emsp; WhatsApp: <a href="https://wa.me/6287721784492" target="blank">+62
                                                877-2178-4492</a><br>
                                            <b>Aditya Surya </b><br>
                                            &emsp; id Line : noname444<br>
                                            &emsp; WhatsApp: <a href="https://wa.me/628967687713" target="blank">+62
                                                896-7687-7139</a><br>
                                    </div>
                                </div>
                            </table>
                        </div>
                    </div>



                <!--ELECTRA-->

                    <div class="tab-pane fade show " id="electra" role="tabpanel" aria-labelledby="electra-tab">
                        <!-- Light table -->
                        <div class="table-responsive">
                            <table class="table align-items-center ">
                                <div class="media-body p-4">


                                    <div class="timeline mb-5">
                                        <h3>Time Line</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            - Pendaftaran: 22 November 2021 s/d 21 Januari 2022 <br>
                                            - Try Out: Sabtu, 22 Januari 2022 <br>
                                            - Babak Penyisihan: Sabtu, 29 Januari 2022 <br>
                                            - Babak Semifinal: Minggu, 30 Januari 2022 <br>
                                            - Babak Grand Final: Minggu, 6 Februari 2022 <br>
                                        </span>
                                    </div>
                                    <div class="info-grup mb-5">
                                        <h3>Grup Peserta</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            Peserta yang sudah terdaftar dan memiliki kartu peserta dapat bergabung pada grup telegram peserta ELECTRA 11 pada link : <a href='https://intip.in/InfoELECTRA11' target="blank"> intip.in/InfoELECTRA11</a> <br>
                                            Segala bentuk informasi terkait dengan acara dan teknis disetiap babak nantinya akan diinformasikan di grup tersebut. Terima kasih.
                                        </span>
                                    </div>
                                    <div class="info-pendaftaran mb-5">
                                        <h3>Informasi Pendaftaran</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">Pendaftaran Online <br>
                                            1. Buka website evolution-its.com <br>
                                            2. Buat akun baru dengan username berupa email dan password kemudian verifikasi <br>
                                            3. Setelah verifikasi silahkan login kembali pada website evolution-its.com <br>
                                            4. Pilih menu “Pendaftaran” dan isi kelengkapan data tim, pastikan memilih “electra” pada saat mengisi kelengkapan pendaftaran <br>
                                            5. Jika data pendaftaran telah lengkap dan benar, silahkan melakukan pembayaran biaya pendaftaran pada no. rekening atau no. OVO yang disediakan dan wajib mengupload bukti transfer pembayaran pada menu “ Pembayaran “ <br>
                                            6. Pendaftar dimohon menunggu verifikasi pembayaran. Pembayaran akan diverifikasi maksimal H+2 setelah upload bukti pembayaran. <br>
                                            7. Setelah pembayaran diverifikasi, maka seluruh proses registrasi selesai. Pendaftar akan menerima email kwitansi pembayaran dan dapat mengunduh kartu tanda peserta pada menu “ Cetak Kartu Peserta “. <br>
                                            8. Kartu peserta wajib diunduh dan digunakan saat Penyisihan ELECTRA 11. <br>
                                            9. Jika lebih dari H+2 pembayaran belum diverifikasi dapat menghubungi CP Electra 11 : 0857 4641 0008 (Addar) <br>
                                            <br>Pendaftaran Offline <br>
                                            1. Pendaftar menghubungi Korlap Region masing-masing pada CP yang telah tersedia di Guidebook ELECTRA 11 <br>
                                            2. Pendaftar mengisi form pendaftaran yang telah disediakan Korlap Region dan melunasi biaya pendaftaran. <br>
                                            3. Setelah pendaftar melunasi biaya pendaftaran maka akan mendapatkan checklist berisi username ( email peserta ) dan password untuk digunakan login ke website evolution-its.com <br>
                                            4. Pendaftar melakukan login ke web evolution-its.com untuk validasi kelengkapan data tim dan mengunduh kartu tanda peserta pada menu “ Cetak Kartu Peserta “. <br>
                                            5. Kartu peserta wajib diunduh dan digunakan saat Penyisihan ELECTRA 11. <br>
                                            6. Jika lebih dari H+2 pendaftaran ke Korlap Region dan belum terdapat menu cetak kartu peserta maka dapat menghubungi CP Electra 11 : 0857 4641 0008 (Addar) <br>
                                    </div>
                                    </span>
                                    <div class="link-penting">
                                        <h3>Link Penting</h3>
                                        <span class="name mb-0 text-sm" style="text-align: justify;">
                                            1.Guidebook ELECTRA 11 : <a href="https://intip.in/GuidebookELECTRA11" target="blank">intip.in/GuidebookELECTRA11</a> <br>
                                            2. Arsip Soal ELECTRA 11 : <a href="https://intip.in/CekSoalElectra" target="blank">intip.in/CekSoalElectra</a> <br>
                                            3. Grup Peserta ELECTRA 11 : <a href="https://intip.in/InfoELECTRA11" target="blank">intip.in/InfoELECTRA11</a> <br>
                                            4. Rundown Tamu ELECTRA 11 : <a href="https://docs.google.com/document/d/1LvEUghpbnf4Hqs7zSrB9BK0OAe6XGc9D/edit?usp=sharing&ouid=100905276312373888312&rtpof=true&sd=true" target="blank">intip.in/RundownTamuELECTRA11</a> <br>
                                            5. Tata Tertib Try Out ELECTRA 11 : <a href="https://intip.in/TatibTryOutElectra" target="blank">intip.in/TatibTryOutElectra</a> <br>
                                            6. Tata Tertib Penyisihan ELECTRA 11 : <a href="https://intip.in/TatibPenyisihanElectra11" target="blank">intip.in/TatibPenyisihanElectra11</a> <br>
                                        </span>
                                    </div>

                                    <div>
                                        <br>
                                        <h3>Rundown Penyisihan ELECTRA 11</h3>
                                        <table border="1" cellpadding="5" class="ml-4">
                                            <tr>
                                                <td>Waktu</td>
                                                <td>Kegiatan</td>
                                            </tr>
                                            <tr>
                                                <td>08.00 - 08.30</td>
                                                <td>Penyambutan Peserta</td>
                                            </tr>
                                            <tr>
                                                <td>08.30 - 08.55</td>
                                                <td>Pembukaan oleh MC</td>
                                            </tr>
                                            <tr>
                                                <td>08.55 - 09.30</td>
                                                <td>Sambutan dan Ceremony Pembukaan Electra</td>
                                            </tr>
                                            <tr>
                                                <td>09.30 - 09.45</td>
                                                <td>Persiapan Pengerjaan Soal</td>
                                            </tr>
                                            <tr>
                                                <td>09.45 - 11.45</td>
                                                <td>Pengerjaan Soal Penyisihan</td>
                                            </tr>
                                            <tr>
                                                <td>11.45 - 12.45</td>
                                                <td>Ishoma</td>
                                            </tr>
                                            <tr>
                                                <td>12.45 - 13.00</td>
                                                <td>Pengkondisian Peserta </td>
                                            </tr>
                                            <tr>
                                                <td>13.00 - 13.30</td>
                                                <td>Pencerdasan Elektro </td>
                                            </tr>
                                            <tr>
                                                <td>13.30 - 13.40</td>
                                                <td>Ice Breaking</td>
                                            </tr>
                                            <tr>
                                                <td>13.40 - 14.10</td>
                                                <td>Pemaparan Lab Teknik Elektro</td>
                                            </tr>
                                            <tr>
                                                <td>14.10 - 14.40</td>
                                                <td>Pengumuman Peserta yang Lolos</td>
                                            </tr>
                                            <tr>
                                                <td>14.40 - 15.10</td>
                                                <td>Apresiasi Peserta, Doa, dan Penutup </td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div>
                                        <br>
                                        <h3 class="ml-4">Rundown Semifinal ELECTRA 11</h3>
                                        <table border="1" cellpadding="5" class="ml-4">
                                            <tr>
                                                <td>Waktu</td>
                                                <td>Kegiatan</td>
                                            </tr>
                                            <tr>
                                                <td>08.00-08.30</td>
                                                <td>Registrasi Semifinalis</td>
                                            </tr>
                                            <tr>
                                                <td>08.30-08.40</td>
                                                <td>Pembukaan</td>
                                            </tr>
                                            <tr>
                                                <td>08.40-08.50</td>
                                                <td>Pembacaan tata tertib pretest</td>
                                            </tr>
                                            <tr>
                                                <td>08.50- 10.40</td>
                                                <td>SESI 1 : Pretest</td>
                                            </tr>
                                            <tr>
                                                <td>10.40 - 11.00</td>
                                                <td>Pembacaan Tata Tertib Praktikum </td>
                                            </tr>
                                            <tr>
                                                <td>11.00 - 11.50</td>
                                                <td>SESI 2 : Praktikum</td>
                                            </tr>
                                            <tr>
                                                <td>11.50 - 12.00</td>
                                                <td>Pengumuan hasil pretest</td>
                                            </tr>
                                            <tr>
                                                <td>12.00 - 13.00</td>
                                                <td>ISHOMA</td>
                                            </tr>
                                            <tr>
                                                <td>13.00 - 13.10</td>
                                                <td>Pengkondisian Semifinalis</td>
                                            </tr>
                                            <tr>
                                                <td>13.10 - 13.25</td>
                                                <td>Persiapan dan pembacaan tata tertib Rally</td>
                                            </tr>
                                            <tr>
                                                <td>13.25 - 13.40</td>
                                                <td>Uji coba breakoutroom</td>
                                            </tr>
                                            <tr>
                                                <td>13.40 - 15.10</td>
                                                <td>SESI 3 : RALLY</td>
                                            </tr>
                                            <tr>
                                                <td>15.10 - 15.20</td>
                                                <td>Penutupan</td>
                                            </tr>
                                        </table>
                                    </div>

                                    <div>
                                        <br>
                                        <h3 class="ml-4">Rundown Final ELECTRA 11</h3>
                                        <table border="1" cellpadding="5" class="ml-4 mb-4">
                                            <tr>
                                                <td>Waktu</td>
                                                <td>Kegiatan</td>
                                            </tr>
                                            <tr>
                                                <td>07:30 - 08:00</td>
                                                <td>Registrasi </td>
                                            </tr>
                                            <tr>
                                                <td>08:00 - 08:10</td>
                                                <td>Pembukaan Oleh MC</td>
                                            </tr>
                                            <tr>
                                                <td>08:10 - 08:20</td>
                                                <td>Sambutan dan Apresiasi oleh Ketua Departemen dan Ketua Electra </td>
                                            </tr>
                                            <tr>
                                                <td>08:20 - 08:50</td>
                                                <td>Pencerdasan Modul Praktikum </td>
                                            </tr>
                                            <tr>
                                                <td>08:50 - 09:00</td>
                                                <td>Perkenalan Juri  </td>
                                            </tr>
                                            <tr>
                                                <td>09:00 - 10:00</td>
                                                <td>Sesi 1: PRAKTIKUM </td>
                                            </tr>
                                            <tr>
                                                <td>10:00 - 10:10</td>
                                                <td>Pengondisian oleh MC dan pengundian</td>
                                            </tr>
                                            <tr>
                                                <td>10:10 - 10:20</td>
                                                <td>Pembacaan Tata Tertib dan Teknis Presentasi </td>
                                            </tr>
                                            <tr>
                                                <td>10:20 - 12:00</td>
                                                <td>Sesi 2: PRESENTASI </td>
                                            </tr>
                                            <tr>
                                                <td>12:00 - 13:00</td>
                                                <td>ISHOMA</td>
                                            </tr>
                                            <tr>
                                                <td>13:00 - 13:10</td>
                                                <td>Pembukaan Kembali Oleh MC</td>
                                            </tr>
                                            <tr>
                                                <td>13:10 - 13:20</td>
                                                <td>Pembacaan Tata Tertib dan Teknis Test Essay</td>
                                            </tr>
                                            <tr>
                                                <td>13:20 - 14:00</td>
                                                <td>Sesi 3: TEST ESSAY</td>
                                            </tr>
                                            <tr>
                                                <td>14:00- 14:10</td>
                                                <td>Ice Breaking</td>
                                            </tr>
                                            <tr>
                                                <td>14:10 - 14:20</td>
                                                <td>Pembacaan Tata Tertib dan Teknis Cerdas Cermat</td>
                                            </tr>
                                            <tr>
                                                <td>14:20- 15:50</td>
                                                <td>Sesi 4: CERDAS CERMAT</td>
                                            </tr>
                                            <tr>
                                                <td>15:50 - 16:00</td>
                                                <td>Ice Breaking</td>
                                            </tr>
                                            <tr>
                                                <td>16:00 - 16:30</td>
                                                <td>Pengumuman Pemenang dan Dokumentasi</td>
                                            </tr>
                                            <tr>
                                                <td>16:30 - 16:40</td>
                                                <td>Penutupan</td>
                                            </tr>
                                        </table>
                                    </div>

                                </div>
                            </table>
                        </div>
                    </div>
                    
				
							

                </div>
            </div>
        </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user/template/user-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\evolution_23\resources\views/user/dashboard.blade.php ENDPATH**/ ?>