<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Email</title>
</head>

<body>
    <p>
        Yaayy! Selamat pembayaran kamu telah dikonfirmasi.
        Terima kasih Tim {{$nama_tim}} atas partisipasinya dalam kompetisi ELECTRA-11 2022. <br>
        Jangan lupa untuk bergabung pada grup telegram peserta ELECTRA 11 di link intip.in/InfoELECTRA11 dan mengunduh kartu peserta kalian di web EVOLUTION 2022 yaitu evolution-its.com ya! <br>
        Tetap semangat untuk lomba nya yaa! Semoga mendapatkan hasil terbaik yang kalian impikan.<br>
        <br> Jika ada yang ingin ditanyakan dapat menghubungi CP : 62 857 4641 0008 ( Addar )
    </p>
</body>

</html>