<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\UserController;
use App\Http\Controllers\AdminController;

use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    // return view('User.index');
    return view("coming-soon.coming_soon");
});

Route::get('/login', function () {
    return view('guest.login');
})->name('login');

Route::get('/register', function () {
    return view('guest.register');
});

Route::get("/electra", function () {
    return view("guest.electra_article");
});

Route::get("/baronas", function () {
    return view("guest.baronas_article");
});

Route::get("/evolve", function () {
    return view("guest.evolve_article");
});
Route::get('/logout', function () {
    Auth::logout();
    return redirect('/');
})->name('user.logout');
Route::post("/register-account", [UserController::class, "register"]);
Route::post("/login-account", [UserController::class, "login"]);

///////////////////////// USER ROUTES //////////////////////////
Route::group(['middleware' => ['auth', 'cekrole:0']], function () {
    Route::get('/user/dashboard', function () {
        return view('user.dashboard');
    });

    // Ganti Password
    Route::get('/user/ganti-password', function () {
        return view('account.change-password');
    });

    Route::get('/user/daftar/electra', [UserController::class, 'tampilanFormElectra']);
    Route::post('/user/daftar/electra', [UserController::class, 'daftarElectra'])->name('user.daftarElectra');

    Route::post('/user/ganti-password', [UserController::class, 'updatePassword'])->name('user.updatePassword');
    Route::get('/user/pembayaran/electra', [UserController::class, 'tampilanBayarElectra']);
    Route::post('/user/pembayaran/electra', [UserController::class, 'bayarElectra'])->name('user.bayarElectra');

    Route::get('/user/kartu/electra', [UserController::class, 'tampilanKartuElectra']);
    Route::get('/user/kartu/electra/unduh', [UserController::class, 'unduhKartuElectra']);
});

///////////////////////// ADMIN ROUTES //////////////////////////
Route::group(['middleware' => ['auth', 'cekrole:1']], function () {
    Route::get('/admin/dashboard', function () {
        return view('admin.dashboard');
    });

    // Mendaftarkan Electra
    Route::get('/admin/daftar/electra', [AdminController::class, "TampilanFormElectra"]);
    Route::post('/admin/daftar/electra', [AdminController::class, 'DaftarElectra'])->name('admin.daftarElectra');

    // Tabel Peserta Electra
    Route::get('/admin/list/electra', [AdminController::class, 'TampilanTabelElectra']);
    Route::get('/admin/list/electra/konfirmasi/{id}', [AdminController::class, 'ActionTabelElectraKonfirmasi']);
    Route::get('/admin/list/electra/delete/{id}', [AdminController::class, 'ActionTabelElectraDelete']);
    Route::post('/admin/list/electra/edit', [AdminController::class, 'ActionTabelElectraEdit'])->name('admin.actionTabelElectraEdit');
    Route::get('/admin/excel/electra', [AdminController::class, 'ExportElectra']);
    Route::get('/admin/list/electra/editing/{id}', [AdminController::class, 'EditingElectraLayout']);
    Route::post('/admin/list/electra/confrimediting', [AdminController::class, 'ConfirmEditingElectraLayout'])->name('admin.editElectra');
    Route::get('/admin/list/electra/lolos/{id}', [AdminController::class, 'LolosSemifinal']);
});
