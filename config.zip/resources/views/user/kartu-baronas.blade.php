@extends('user/template/user-template')

@section('title', 'Unduh Kartu Peserta | Evolution 2022')

@section('container')

<!-- Header -->
<div class="header bg-default pb-6">
    <div class="container-fluid">
        <div class="header-body">
            <div class="row align-items-center py-4">
                <div class="col-lg-6 col-7">
                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block">
                        <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                            <li class="breadcrumb-item"><a><i class="fas fa-home" style="color: #172B4D"></i></a></li>
                            <li class="breadcrumb-item"><a style="color: #172B4D">Kartu Peserta</a></li>

                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Page content -->
<div class="container-fluid mt--6">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card">
                <div class="card-header bg-transparent">
                    @if (($baronas['pembayaran_status']==2 || $baronas['pembayaran_status']==4) && $baronas['kategori'] != 'UMUM' && $baronas['email'] != null)
                    <h3 class="mb-0">Berikut Kartu Peserta dan Nametag Robot</h3>
                    @endif
                    @if (($baronas['pembayaran_status']==2 || $baronas['pembayaran_status']==4) && $baronas['kategori'] == 'UMUM' && $baronas['email'] != null)
                    <h3 class="mb-0">Berikut Kartu Peserta Untuk Masing-Masing Peserta</h3>
                    @endif
                </div>

                <div class="card-body">
                    @if ($baronas['pembayaran_status']==0 && $baronas['email'] != null)
                    <div class="alert alert-warning alert-block">
                        <strong>Segera lakukan pembayaran untuk mengakses kartu peserta</strong>
                    </div>
                    @endif
                    @if (($baronas['pembayaran_status']==1 || $baronas['pembayaran_status']==3 ) && $baronas['email'] != null)
                    <div class="alert alert-warning alert-block">
                        <strong>Harap tunggu, data Anda sedang dalam proses verifikasi oleh Admin</strong>
                    </div>
                    @endif

                    @if (($baronas['pembayaran_status']==2 || $baronas['pembayaran_status']==4) && $baronas['kategori'] != "UMUM" && $baronas['email'] != null)
                    <div class="row d-flex justify-content-center">
                        <div class="col-12 col-md-4" style="width: 100%;">
                            <div class="card" style="width: 100%;">
                                <a style="text-align: center;" class="p-3">
                                    <!-- <img class=" card-img-top p-2" src="/img/dokumen/kartu-peserta.jpg" " alt=""  style=" width: 50%; margin: 0 auto;"> -->
                                    <i style="color: #264579;" class="far fa-id-badge fa-10x"></i>
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">Nametag Baronas</h5>
                                    <a href="{{url('/user/kartu-peserta-baronas/unduh')}}" class="btn text-lighter" style="display:flex; justify-content: center; align-items: center; background-color: #264579;">Unduh Nametag</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row d-flex justify-content-center">
                        <div class="col-12 col-md-4" style="width: 100%;">
                            <div class="card" style="width: 100%;">
                                <a style="text-align: center;" class="p-3">
                                    <i style="color: #264579;" class="far fa-address-card fa-10x"></i>
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">Nametag Robot Baronas</h5>
                                    <a href="{{url('/user/kartu-peserta-baronas/unduh-nametag-robot')}}" class="btn text-lighter" style="display:flex; justify-content: center; align-items: center; background-color: #264579;">Unduh Nametag Robot</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                    @if (($baronas['pembayaran_status']==2 || $baronas['pembayaran_status']==4) && $baronas['kategori'] == "UMUM" && $baronas['email'] != null)
                    <div class="row d-flex justify-content-center">
                        <div class="col-12 col-md-4" style="width: 100%;">
                            <div class="card" style="width: 100%;">
                                <a style="text-align: center;" class="p-3">
                                    <i style="color: #264579;" class="far fa-id-badge fa-10x"></i>
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title" style="font-size: xx-large; text-align: center;">Nametag Baronas</h5>
                                    <a href="{{url('/user/kartu-peserta-baronas/unduh')}}" class="btn text-lighter" style="display:flex; justify-content: center; align-items: center; background-color: #264579;">Unduh Nametag</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endif

                    @if ($baronas['email'] == null)
                    <div class="alert alert-warning alert-block">
                        <strong>Anda belum mendaftar lomba apapun</strong>
                    </div>
                    @endif
                </div>
            </div>
            @endsection