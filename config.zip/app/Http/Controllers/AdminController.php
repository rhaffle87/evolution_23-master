<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Barryvdh\DomPDF\PDF;
use Excel;

use App\Models\User;
use App\Models\Electra;


class AdminController extends Controller
{
    public function TampilanFormElectra()
    {
        $electra = Electra::where("email", "=", Auth::user()->email)->first();

        if ($electra == null)
            $electra = new Electra;

        return view('admin.daftar-electra', compact('electra'));
    }

    public function DaftarElectra(Request $request)
    {
        // selain mendaftarkan lomba, juga mendaftarkan akun
        if (Auth::user()->email == 'evolutionits2022@gmail.com') {
            $rules = array('email' => 'required|email|unique:users,email', 'password' => 'required|min:8');

            $input['email'] = $request->email;
            $input['password'] = "evolution2022";
            $validator = Validator::make($input, $rules);

            if ($validator->fails()) {
                return redirect('/admin/daftar/electra')->with('failed', $request->email);
            } else {
                User::create([
                    'email' => $request->email,
                    'password' => Hash::make($input['password']),
                    'level' => 0,
                    'akses_update' => 0,
                    'register_status' => 1,
                ]);
            }

            // convert to uppercase
            $request->nama_tim = strtoupper($request->nama_tim);
            $request->nama_ketua = strtoupper($request->nama_ketua);
            $request->nama_anggota = strtoupper($request->nama_anggota);

            $daftar = new Electra;

            $daftar->email              = $request->email;
            $daftar->id_semifinal       = 0;
            $daftar->nama_tim           = $request->nama_tim;
            $daftar->nama_ketua         = $request->nama_ketua;
            $daftar->kelas_ketua        = $request->kelas_ketua;
            $daftar->nama_anggota       = $request->nama_anggota;
            $daftar->kelas_anggota      = $request->kelas_anggota;
            $daftar->sekolah            = $request->sekolah;
            $daftar->alamat_sekolah     = $request->alamat_sekolah;
            $daftar->nomor_hp_ketua     = $request->nomor_hp_ketua;
            $daftar->nomor_hp_anggota   = $request->nomor_hp_anggota;
            $daftar->region             = $request->region;
            $daftar->pembayaran_status  = 3; // register via korlap dan sudah lunas
            $daftar->file_ktp_ketua     = $request->file_ktp_ketua->store('public');
            $daftar->file_ktp_anggota   = $request->file_ktp_anggota->store('public');
            $daftar->save();

            return redirect('/admin/daftar/electra')->with('success', $request->nama_tim);
        } else {
            // apabila terdeteksi bukan admin, otomatis logout
            $request->session()->flush();
            Auth::logout();
            return redirect('/');
        }
    }

    public function TampilanTabelElectra()
    {
        $list_electra = DB::table('electras')->get();
        return view('admin.list-electra', ['list_electra' => $list_electra]);
    }

    public function ActionTabelElectraKonfirmasi($id)
    {
        $electra = Electra::find($id);

        if ($electra->pembayaran_status == 3)
            $electra->pembayaran_status = 4;
        else if ($electra->pembayaran_status == 1)
            $electra->pembayaran_status = 2;

        $data_target = DB::table('electras')->where('id', $id)->first();
        // generate dari menurut region
        $e = 1;
        $region = $data_target->region;
        if ($region == null) {
            $x = 0;
            $y = 0;
            $e = 2;
        } else if ($region == 'Jabodetabek') {
            $x = 1;
            $y = 5;
        } else if ($region == 'Banyuwangi') {
            $x = 1;
            $y = 1;
        } else if ($region == 'Madiun') {
            $x = 0;
            $y = 9;
        } else if ($region == 'Tuban') {
            $x = 0;
            $y = 6;
        } else if ($region == 'Semarang') {
            $x = 1;
            $y = 4;
        } else if ($region == 'Malang') {
            $x = 0;
            $y = 5;
        } else if ($region == 'Surabaya') {
            $x = 0;
            $y = 1;
        } else if ($region == 'Sidoarjo') {
            $x = 0;
            $y = 2;
        } else if ($region == 'Bali') {
            $x = 1;
            $y = 6;
        } else if ($region == 'Gresik') {
            $x = 0;
            $y = 3;
        } else if ($region == 'Balikpapan') {
            $x = 1;
            $y = 7;
        } else if ($region == 'Jember') {
            $x = 1;
            $y = 0;
        } else if ($region == 'Kediri') {
            $x = 0;
            $y = 8;
        } else if ($region == 'Mojokerto') {
            $x = 0;
            $y = 4;
        } else if ($region == 'Madura') {
            $x = 1;
            $y = 2;
        } else if ($region == 'Probolinggo') {
            $x = 0;
            $y = 7;
        } else if ($region == 'Solo') {
            $x = 1;
            $y = 3;
        }

        // genegrate nomor register berdasarkan id
        $nomor_peserta = $data_target->id;
        $syarat = $nomor_peserta / 10;
        if ($syarat < 1) {
            // 1 sampai 9
            $a = 0;
            $b = 0;
            $c = 0;
            $d = substr($nomor_peserta, 0, 1);
        } else if ($syarat < 10 && $syarat >= 1) {
            // 10 sampai 99
            $a = 0;
            $b = 0;
            $c = substr($nomor_peserta, 0, 1);
            $d = substr($nomor_peserta, 1, 1);
        } else if ($syarat >= 10 && $syarat < 100) {
            // 100 sampai 999
            $a = 0;
            $b = substr($nomor_peserta, 0, 1);
            $c = substr($nomor_peserta, 1, 1);
            $d = substr($nomor_peserta, 2, 1);
        } else if ($syarat >= 100) {
            // 1000 sampai 9999
            $a = substr($nomor_peserta, 0, 1);
            $b = substr($nomor_peserta, 1, 1);
            $c = substr($nomor_peserta, 2, 1);
            $d = substr($nomor_peserta, 3, 1);
        }

        $biaya = '60.000';
        $email = $data_target->email;
        $data = array(
            'nama_tim' => $data_target->nama_tim,
            'nama_ketua' => $data_target->nama_ketua,
            'nama_anggota' => $data_target->nama_anggota,
            'biaya' => $biaya,
            'digit_pertama' => $a,
            'digit_kedua' => $b,
            'digit_ketiga' => $c,
            'digit_keempat' => $d,
            'region_pertama' => $x,
            'region_kedua' => $y,
            'kode_akses' => $e,
        );

        $no_peserta_jadi = $x . $y . '-20' . $a . '-' . $b . $c . $d . '-' . $e;

        $electra->no_pendaftaran = $no_peserta_jadi;
        $electra->save();

        $pdf = PDF::loadView('document.bukti-pembayaran', $data)->setPaper('a5', 'landscape');

        Mail::send('email.email-layout', $data, function ($message) use ($email, $pdf) {

            $message->to($email, $email)
                ->subject('BUKTI PEMBAYARAN ELECTRA-11 2022')
                ->attachData($pdf->output(), "kuitansi.pdf");
            $message->from('evolutionits2022@gmail.com');
        });

        // jika gagal
        if (Mail::failures())
            return redirect('/admin/list/electra')->with('email-fail', 'Email gagal dikirim');

        else
            return redirect('/admin/list/electra')->with('email-success', 'Data berhasil diverifikasi');
    }

    public function actionTabelElectraDelete($id)
    {
        // menghapus akun electra dan evolution
        $electra = Electra::find($id);
        $electra->delete();

        $user = User::where("email", "=", $electra->email)->first();
        $user->delete();

        return redirect('/admin/list/electra')->with('success', "Akun $electra->email / $electra->nama_tim berhasil di hapus");
    }

    public function actionTabelElectraEdit(Request $request)
    {
        if (DB::table('electras')->where("email", $request->email)
            ->update(
                [
                    "nama_tim" => $request->nama_tim,
                    "nama_ketua" => $request->nama_ketua,
                    "kelas_ketua" => $request->kelas_ketua,
                    "nama_anggota" => $request->nama_anggota,
                    "kelas_anggota" => $request->kelas_anggota,
                    "sekolah" => $request->sekolah,
                    "alamat_sekolah" => $request->alamat_sekolah,
                    "nomor_hp_ketua" => $request->nomor_hp_ketua,
                    "nomor_hp_anggota" => $request->nomor_hp_anggota,
                ]
            )
        ) {
            return redirect('/admin/list/electra')->with('success-update', "Data berhasil diubah");
        } else {
            return redirect('/admin/list/electra')->with('failed', "Data gagal diubah, tidak ada perubahan pada data");
        }
    }

    public function exportElectra()
    {
        return Excel::download(new ElectraExport, 'Electra.xlsx');
    }

    public function EditingElectraLayout($id)
    {
        $electra = Electra::find($id);
        return view('admin.edit-electra', ['electra' => $electra]);
    }

    public function ConfirmEditingElectraLayout(Request $request)
    {
        if (DB::table('electras')->where("email", $request->email)
            ->update(
                [
                    "nama_tim" => $request->nama_tim,
                    "nama_ketua" => $request->nama_ketua,
                    "kelas_ketua" => $request->kelas_ketua,
                    "nama_anggota" => $request->nama_anggota,
                    "kelas_anggota" => $request->kelas_anggota,
                    "sekolah" => $request->sekolah,
                    "alamat_sekolah" => $request->alamat_sekolah,
                    "nomor_hp_ketua" => $request->nomor_hp_ketua,
                    "nomor_hp_anggota" => $request->nomor_hp_anggota,
                ]
            )
        ) {
            return redirect('/admin/list/electra')->with('success-update', "Data berhasil diubah");
        } else {
            return redirect('/admin/list/electra')->with('failed', "Data gagal diubah, tidak ada perubahan pada data");
        }
    }

    public function LolosSemifinal($id)
    {
        $electra = Electra::find($id);
        DB::table('electras')->where("id", $id)->update(['status_lolos' => 1]);
        return redirect('/admin/list/electra')->with('sukses', "Tim $electra->nama_tim lolos Semifinal");
    }
}
